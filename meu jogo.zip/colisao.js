function bate(objeto, novoX, novoY){

    return (
        novoX < objeto.x + objeto.largura &&
        novoX + player.offsetWidth > objeto.x &&
        novoY < objeto.y + objeto.altura &&
        novoY + player.offsetHeight > objeto.y
    );

}