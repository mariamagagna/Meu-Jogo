// =====================================
// OBJETOS DO QUARTO
// =====================================

const objetos = [

    {
        nome: "cama",

        x: 60,
        y: 40,

        largura: 150,
        altura: 80,

        interacao: "Você deitou na cama."
    },

    {
        nome: "porta",

        x: 870,
        y: 20,

        largura: 70,
        altura: 110,

        interacao: "Você saiu do quarto."
    },

    {
        nome: "computador",

        x: 650,
        y: 300,

        largura: 120,
        altura: 80,

        interacao: "Você ligou o computador."
    },

    {
        nome: "estante",

        x: 720,
        y: 70,

        largura: 120,
        altura: 170,

        interacao: "Há vários livros aqui."
    }

];